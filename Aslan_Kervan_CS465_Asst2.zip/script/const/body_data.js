const torsoHeight = 5.0;
const torsoWidth = 5.0;

const upperArmHeight = 6.0;
const middleArmHeight = 6.0;
const lowerArmHeight = 3.0;

const upperArmWidth = 1.0;
const middleArmWidth = 0.95;
const lowerArmWidth = 0.85;

const headHeight = 4.0;
const headWidth = 4.0;

const eyeSize = 1.85;
const pupilSize = 0.85;

const legCircleRadius = torsoWidth * 0.75;
