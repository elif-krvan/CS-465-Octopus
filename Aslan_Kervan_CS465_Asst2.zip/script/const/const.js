const torsoId = 0;
const torsoIdX = 1;

const leftEyeId = 1;
const rightEyeId = 2;

const leftEyePupilId = 3;
const rightEyePupilId = 4;

const upperArmId1 = 5;
const middleArmId1 = 6;
const lowerArmId1 = 7;

const upperArmId2 = 8;
const middleArmId2 = 9;
const lowerArmId2 = 10;

const upperArmId3 = 11;
const middleArmId3 = 12;
const lowerArmId3 = 13;

const upperArmId4 = 14;
const middleArmId4 = 15;
const lowerArmId4 = 16;

const upperArmId5 = 17;
const middleArmId5 = 18;
const lowerArmId5 = 19;

const upperArmId6 = 20;
const middleArmId6 = 21;
const lowerArmId6 = 22;

const upperArmId7 = 23;
const middleArmId7 = 24;
const lowerArmId7 = 25;

const upperArmId8 = 26;
const middleArmId8 = 27;
const lowerArmId8 = 28;
