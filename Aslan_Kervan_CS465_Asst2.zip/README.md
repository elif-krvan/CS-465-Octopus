# Octop 
### CS465 Fall 2023-2024 Assignment 2: Hierarchical Modeling

+ Group Member 1: Yağız Can Aslan, 22001943.
+ Group Member 2: İlkim Elif Kervan, 22002223.
